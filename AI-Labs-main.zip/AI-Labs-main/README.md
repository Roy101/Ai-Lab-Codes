# AI-Labs
This is the labs i solved during my undergrad ai course whichs code is CSE422
